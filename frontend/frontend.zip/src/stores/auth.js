// src/stores/auth.js (正确版本，无路由依赖)

import { defineStore } from 'pinia';
import apiClient from '@/services/api';
// 1. 移除 import router from '@/router';

export const useAuthStore = defineStore('auth', {
    state: () => ({
        accessToken: localStorage.getItem('accessToken') || null,
        user: JSON.parse(localStorage.getItem('user')) || null,
    }),
    getters: {
        isAuthenticated: (state) => !!state.accessToken,
        isAdmin: (state) => state.user?.is_admin || false,
    },
    actions: {
        async login(credentials) {
            // login action 只负责登录、获取token、更新用户信息
            const response = await apiClient.post('/token/', credentials);
            this.accessToken = response.data.access;
            localStorage.setItem('accessToken', this.accessToken);
            await this.fetchUser();
            // 2. 移除这里的 router.push('/')
        },
        async fetchUser() {
            try {
                const { data } = await apiClient.get('/users/me/');
                this.user = data;
                localStorage.setItem('user', JSON.stringify(this.user));
            } catch (error) {
                console.error("Failed to fetch user:", error);
                // 如果获取用户信息失败（例如token过期），则直接登出
                this.logout();
            }
        },
        logout() {
            // logout action 只负责清空状态和本地存储
            this.accessToken = null;
            this.user = null;
            localStorage.removeItem('accessToken');
            localStorage.removeItem('user');
            // 3. 移除这里的 router.push('/login')
        },
    },
});