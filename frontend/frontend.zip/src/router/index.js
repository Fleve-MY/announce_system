// src/router/index.js (最终调试版)

import { createRouter, createWebHistory } from 'vue-router';
import { useAuthStore } from '@/stores/auth';
import DefaultLayout from '@/layouts/DefaultLayout.vue';
import Home from '@/views/Home.vue';
import Login from '@/views/Login.vue';
import Feedback from '@/views/Feedback.vue';
import AdminDashboard from '@/views/AdminDashboard.vue';
import EditAnnouncement from '@/views/EditAnnouncement.vue';
import EditUser from '@/views/EditUser.vue';

const routes = [
    { path: '/login', name: 'Login', component: Login },
    {
        path: '/',
        component: DefaultLayout,
        meta: { requiresAuth: true }, // 我们保留 meta 字段用于测试
        children: [
            { path: '', name: 'Home', component: Home },
            { path: 'feedback', name: 'Feedback', component: Feedback },
            {
                path: 'admin',
                name: 'AdminDashboard',
                component: AdminDashboard,
                meta: { requiresAdmin: true },
            },
            {
                path: 'admin/announcement/edit/:id',
                name: 'EditAnnouncement',
                component: EditAnnouncement,
                meta: { requiresAdmin: true },
                props: true,
            },
            {
                path: 'admin/user/edit/:id',
                name: 'EditUser',
                component: EditUser,
                meta: { requiresAdmin: true },
                props: true,
            },
        ],
    },
];

const router = createRouter({
    history: createWebHistory(import.meta.env.BASE_URL),
    routes,
});

// ======================================================
//         最终调试用的、最简化的导航守卫
// ======================================================
router.beforeEach((to, from, next) => {
  console.log('Navigating to:', to.fullPath); // 1. 添加日志，看守卫是否执行
  try {
    const authStore = useAuthStore();
    console.log('Successfully accessed auth store. IsAuthenticated:', authStore.isAuthenticated); // 2. 添加日志
  } catch (e) {
    console.error('Error accessing auth store in guard:', e); // 3. 添加错误捕获
  }
  next(); // 4. 直接放行所有路由，不进行任何判断
});

export default router;